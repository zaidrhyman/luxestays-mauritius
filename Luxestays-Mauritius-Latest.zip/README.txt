LUXESTAYS MAURITIUS WEBSITE

Open index.html in a browser. Upload all HTML files, styles.css and script.js to a static hosting provider to publish.

IMPORTANT BEFORE LAUNCH:
1. Replace all illustrative Unsplash photographs with owner-approved property photos.
2. Add your verified business contact email or WhatsApp number and connect a working enquiry delivery service. Currently the form prepares a copyable enquiry but does not send it.
3. Confirm property details against your listings.
4. Add actual business information, cancellation/booking terms, privacy policy and any legally required notices.
5. Do not claim live availability, instant bookings or online payments until integrated and tested.
6. To accept card payments, use a supported licensed payment provider and secure hosted checkout.
7. To avoid double bookings, use a tested channel manager or calendar integration.

New pages: hosts.html and experiences.html. The car hire/activities form generates a copyable booking request; it does not submit or reserve anything until an owner contact destination/backend is configured. Host names and 900+ stays statement were supplied by the owner and should be verified before publication.
