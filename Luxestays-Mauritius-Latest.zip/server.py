"""Luxestays starter booking backend. Python standard library only.
Run: python server.py; configure ADMIN_PASSWORD and SESSION_SECRET first.
Payment integration NOT configured: reservations are held as pending_payment.
"""
import os, json, sqlite3, secrets, hashlib, hmac, base64, html, re, mimetypes
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from http.cookies import SimpleCookie

ROOT=Path(__file__).resolve().parent
DB=Path(os.getenv('LUXESTAYS_DB',str(ROOT/'luxestays.db')))
SECRET=os.getenv('SESSION_SECRET','')
PASSWORD=os.getenv('ADMIN_PASSWORD','')
HOST=os.getenv('HOST','127.0.0.1')
PORT=int(os.getenv('PORT','8000'))
VILLAS={'pearl':'The Pearl Villa','opal':'The Opal Villa'} # initial seed only
MAX_NIGHTS=90

def conn():
 c=sqlite3.connect(DB,timeout=15,isolation_level=None)
 c.row_factory=sqlite3.Row
 c.execute('PRAGMA busy_timeout=15000')
 return c

def setup():
 with conn() as c:
  c.execute('PRAGMA journal_mode=WAL')
  c.executescript('''CREATE TABLE IF NOT EXISTS villas(id TEXT PRIMARY KEY,name TEXT NOT NULL,nightly INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS reservations(id TEXT PRIMARY KEY,villa TEXT NOT NULL,guest TEXT NOT NULL,email TEXT NOT NULL,guests INTEGER NOT NULL,arrival TEXT NOT NULL,departure TEXT NOT NULL,amount INTEGER NOT NULL,status TEXT NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS blocked(id INTEGER PRIMARY KEY AUTOINCREMENT,villa TEXT NOT NULL,arrival TEXT NOT NULL,departure TEXT NOT NULL,reason TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS res_dates ON reservations(villa,arrival,departure,status);
 CREATE INDEX IF NOT EXISTS block_dates ON blocked(villa,arrival,departure);''')
  for key,name in VILLAS.items(): c.execute('INSERT OR IGNORE INTO villas(id,name,nightly) VALUES(?,?,?)',(key,name,0))
  cols={r['name'] for r in c.execute('PRAGMA table_info(villas)')}
  for col,definition in [('location',"TEXT NOT NULL DEFAULT ''"),('description',"TEXT NOT NULL DEFAULT ''"),('guests','INTEGER NOT NULL DEFAULT 6'),('bedrooms','INTEGER NOT NULL DEFAULT 2'),('image',"TEXT NOT NULL DEFAULT ''"),('published','INTEGER NOT NULL DEFAULT 1')]:
   if col not in cols:c.execute(f'ALTER TABLE villas ADD COLUMN {col} {definition}')
  c.execute("UPDATE villas SET location='Petit Raffray',guests=7,bedrooms=3 WHERE id='pearl' AND location=''")
  c.execute("UPDATE villas SET location='Trou aux Biches',guests=6,bedrooms=2 WHERE id='opal' AND location=''")

def villa_map(c, published=False):
 return {r['id']:dict(r) for r in c.execute('SELECT * FROM villas'+(' WHERE published=1' if published else '')+' ORDER BY name')}

def villa_label(c,key):
 r=c.execute('SELECT name FROM villas WHERE id=?',(key,)).fetchone()
 return r['name'] if r else key

def esc(x): return html.escape(str(x),quote=True)
def csrf(): return secrets.token_urlsafe(24)
def sign(value): return hmac.new(SECRET.encode(),value.encode(),hashlib.sha256).hexdigest()
def cookie_value():
 payload=base64.urlsafe_b64encode(str(int(datetime.now(timezone.utc).timestamp()+8*3600)).encode()).decode().rstrip('=')
 return payload+'.'+sign(payload)
def authenticated(cookie):
 try:
  token=cookie.get('luxesession').value
  payload,signature=token.split('.',1)
  if not hmac.compare_digest(sign(payload),signature):return False
  expires=int(base64.urlsafe_b64decode(payload+'===').decode())
  return expires>datetime.now(timezone.utc).timestamp()
 except (AttributeError,ValueError,KeyError):return False

def valid_dates(a,b):
 start,end=date.fromisoformat(a),date.fromisoformat(b)
 if start<date.today() or end<=start or (end-start).days>MAX_NIGHTS:raise ValueError('Choose valid future dates, up to 90 nights.')
 return (end-start).days

def occupied(c,v,a,b):
 return c.execute("SELECT 1 FROM reservations WHERE villa=? AND status IN ('pending_payment','confirmed') AND arrival<? AND departure>? LIMIT 1",(v,b,a)).fetchone() or c.execute('SELECT 1 FROM blocked WHERE villa=? AND arrival<? AND departure>? LIMIT 1',(v,b,a)).fetchone()

def layout(title,body):
 return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} | Luxestays</title><link rel="stylesheet" href="/styles.css"><style>.panel{{max-width:1000px;margin:55px auto;padding:0 22px}}.panel form{{background:white;padding:24px;margin:22px 0}}.panel input,.panel select{{padding:12px;width:100%;margin:7px 0 15px;border:1px solid #bbc8bf}}.panel table{{border-collapse:collapse;width:100%;background:white}}.panel th,.panel td{{padding:12px;border-bottom:1px solid #ddd;text-align:left}}.panel .scroll{{overflow-x:auto}}.panel .muted{{color:#667}}.panel .error{{color:#a32922}}.panel .success{{color:#17663e}}.panel .columns{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:22px}}.panel button{{cursor:pointer}}.panel .month{{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:4px}}.panel .day{{padding:8px 3px;text-align:center;background:#e8ede8;font-size:12px;min-height:40px}}.panel .busy{{background:#e9c6a5}}.panel .blocked{{background:#a7b5b0}}.panel .blank{{background:transparent}}</style></head><body><header><div class="nav"><a class="logo" href="/index.html">LUXESTAYS<small>MAURITIUS</small></a><nav class="links" style="display:flex"><a href="/properties">Our villas</a><a href="/book">Book</a><a href="/admin">Dashboard</a></nav></div></header><main class="panel">{body}</main></body></html>'''

def month_calendar(c,v,year,month):
 import calendar
 first=date(year,month,1); last=date(year+1,1,1) if month==12 else date(year,month+1,1)
 reservations=c.execute("SELECT arrival,departure,status FROM reservations WHERE villa=? AND status IN ('pending_payment','confirmed') AND arrival<? AND departure>?",(v,last.isoformat(),first.isoformat())).fetchall()
 blocks=c.execute('SELECT arrival,departure FROM blocked WHERE villa=? AND arrival<? AND departure>?',(v,last.isoformat(),first.isoformat())).fetchall()
 cells=['<div class="day">'+day+'</div>' for day in ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']]
 cells+=['<div class="day blank"></div>']*first.weekday()
 for day in range(1,calendar.monthrange(year,month)[1]+1):
  d=date(year,month,day).isoformat()
  typ='blocked' if any(x['arrival']<=d<x['departure'] for x in blocks) else 'busy' if any(x['arrival']<=d<x['departure'] for x in reservations) else ''
  cells.append(f'<div class="day {typ}" title="{esc(d)}">{day}</div>')
 return f'<h3>{esc(villa_label(c,v))}</h3><div class="month">{"".join(cells)}</div>'

class Handler(BaseHTTPRequestHandler):
 def send(self,status,body,content_type='text/html; charset=utf-8',headers=None):
  raw=body.encode() if isinstance(body,str) else body
  self.send_response(status)
  self.send_header('Content-Type',content_type)
  self.send_header('Content-Length',str(len(raw)))
  self.send_header('X-Content-Type-Options','nosniff')
  self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
  self.send_header('Content-Security-Policy',"default-src 'self' https://images.unsplash.com https://fonts.googleapis.com https://fonts.gstatic.com; img-src 'self' https://images.unsplash.com data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; script-src 'self' 'unsafe-inline'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
  self.send_header('Cache-Control','no-store' if self.path.startswith('/admin') or self.path.startswith('/api') else 'public, max-age=120')
  for k,v in (headers or {}).items():self.send_header(k,v)
  self.end_headers();self.wfile.write(raw)
 def redirect(self,url,headers=None):self.send(303,'',headers={'Location':url,**(headers or {})})
 def read_form(self):
  length=int(self.headers.get('Content-Length','0'))
  if length>10000:raise ValueError('Request too large')
  return {k:v[0] for k,v in parse_qs(self.rfile.read(length).decode('utf-8'),keep_blank_values=True).items()}
 def cookies(self):
  jar=SimpleCookie()
  try:jar.load(self.headers.get('Cookie',''))
  except Exception:pass
  return jar
 def admin_ok(self):return authenticated(self.cookies())
 def token(self):
  jar=self.cookies()
  return jar.get('luxecsrf').value if 'luxecsrf' in jar else ''
 def check_csrf(self,form):return bool(self.token()) and hmac.compare_digest(self.token(),form.get('csrf','')) and (self.headers.get('Origin','') or self.headers.get('Referer','')).startswith(('http://localhost:','http://127.0.0.1:','https://'))
 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/properties':
   with conn() as c: listings=villa_map(c,True)
   cards=''.join(f"<article style='background:white;padding:24px;border-radius:12px'><img style='width:100%;height:220px;object-fit:cover' src='{esc(v['image'])}' alt='{esc(v['name'])}' onerror=\"this.style.display='none'\" ><h2>{esc(v['name'])}</h2><p>{esc(v['location'])} · {v['bedrooms']} bedrooms · up to {v['guests']} guests</p><p>{esc(v['description'])}</p><strong>{'MUR '+format(v['nightly'],',')+'/night' if v['nightly'] else 'Enquire for pricing'}</strong><p><a class='btn' href='/book?villa={esc(v['id'])}'>Check dates & book</a></p></article>" for v in listings.values())
   self.send(200,layout('Our Villas','<h1>Explore our villas</h1><div class="columns">'+(cards or '<p>Properties coming soon.</p>')+'</div>'));return
  if path=='/book':
   with conn() as c: listings=villa_map(c,True)
   selected=parse_qs(urlparse(self.path).query).get('villa',[''])[0]
   options=''.join(f'<option value="{esc(k)}"'+(' selected' if k==selected else '')+f'>{esc(v["name"])} — MUR {v["nightly"]:,}/night</option>' for k,v in listings.items())
   body=f'''<h1>Book your stay</h1><p>Choose your villa and dates. Reservations are currently <strong>pending payment</strong> until our secure payment gateway is activated. Prices are in Mauritian rupees (MUR).</p><form method="post" action="/book"><label>Villa<select name="villa" required>{options}</select></label><label>Check-in<input type="date" name="arrival" min="{date.today()}" required></label><label>Check-out<input type="date" name="departure" min="{date.today()+timedelta(days=1)}" required></label><label>Guests<input type="number" name="guests" min="1" max="50" value="2" required></label><label>Your name<input name="guest" maxlength="120" required></label><label>Email<input type="email" name="email" maxlength="200" required></label><button class="btn">Request reservation</button></form><p class="note">Dates shown here may not reflect Airbnb bookings until a calendar sync is configured. Owners must reconcile Airbnb calendars before accepting payment.</p>'''
   self.send(200,layout('Book your stay',body));return
  if path=='/api/availability':
   q=parse_qs(urlparse(self.path).query)
   try:
    v=q['villa'][0];a=q['arrival'][0];b=q['departure'][0]
    if not re.fullmatch(r'[a-z0-9-]{1,60}',v):raise ValueError('Unknown villa')
    nights=valid_dates(a,b)
    with conn() as c:
     row=c.execute('SELECT nightly FROM villas WHERE id=? AND published=1',(v,)).fetchone()
     if not row:raise ValueError('Unknown villa')
     rate=row['nightly']
     available=not bool(occupied(c,v,a,b))
    self.send(200,json.dumps({'available':available,'nights':nights,'total_mur':rate*nights,'payment_enabled':False}),'application/json');return
   except (KeyError,ValueError) as e:self.send(400,json.dumps({'error':str(e)}),'application/json');return
  if path=='/admin/logout':
   self.redirect('/admin',{'Set-Cookie':'luxesession=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'});return
  if path=='/admin/property' and self.admin_ok():
   q=parse_qs(urlparse(self.path).query);vid=q.get('id',[''])[0]
   with conn() as c: v=c.execute('SELECT * FROM villas WHERE id=?',(vid,)).fetchone() if vid else None
   if vid and not v:self.send(404,'Property not found');return
   token=self.token() or csrf();headers={} if self.token() else {'Set-Cookie':f'luxecsrf={token}; Path=/; SameSite=Strict; HttpOnly'}
   def val(k,default=''):return esc(v[k] if v else default)
   checked='checked' if not v or v['published'] else ''
   body=f'''<h1>{'Edit villa' if v else 'Add a new villa'}</h1><p><a href="/admin">← Back to dashboard</a></p><form method="post" action="/admin/property"><input type="hidden" name="csrf" value="{token}"><input type="hidden" name="id" value="{esc(vid)}"><label>Villa name<input name="name" maxlength="100" value="{val('name')}" required></label><label>Location<input name="location" maxlength="150" value="{val('location')}" required></label><label>Description<textarea name="description" maxlength="3000" style="width:100%;min-height:120px;padding:12px">{val('description')}</textarea></label><label>Nightly price in MUR<input name="nightly" type="number" min="0" max="1000000" value="{val('nightly','0')}" required></label><label>Maximum guests<input name="guests" type="number" min="1" max="50" value="{val('guests','6')}" required></label><label>Bedrooms<input name="bedrooms" type="number" min="0" max="30" value="{val('bedrooms','2')}" required></label><label>Photo URL (https:// only)<input name="image" type="url" maxlength="500" value="{val('image')}" placeholder="https://example.com/villa.jpg"></label><label><input type="checkbox" name="published" value="1" style="width:auto" {checked}> Show on booking website</label><p class="muted">Photo URL support is available now. Uploading files from your device is not implemented yet. New villas with a zero nightly price cannot receive bookings.</p><button class="btn">Save property</button></form>'''
   self.send(200,layout('Manage villa',body),headers=headers);return
  if path.startswith('/admin'):
   if not self.admin_ok():
    self.send(200,layout('Admin login','<h1>Admin sign in</h1><form method="post" action="/admin/login"><label>Password<input type="password" name="password" required></label><button class="btn">Sign in</button></form>'));return
   token=self.token() or csrf()
   headers={} if self.token() else {'Set-Cookie':f'luxecsrf={token}; Path=/; SameSite=Strict; HttpOnly'}
   with conn() as c:
    rows=c.execute('SELECT * FROM reservations ORDER BY arrival ASC').fetchall()
    villas=c.execute('SELECT * FROM villas').fetchall()
    blocked=c.execute('SELECT * FROM blocked ORDER BY arrival').fetchall()
    month=date.today().replace(day=1)
    cal=''.join(month_calendar(c,v['id'],month.year,month.month) for v in villas)
   trs=''.join(f'''<tr><td>{esc(r['id'][:8])}</td><td>{esc(next((v['name'] for v in villas if v['id']==r['villa']),r['villa']))}</td><td>{esc(r['guest'])}<br>{esc(r['email'])}</td><td>{esc(r['arrival'])} → {esc(r['departure'])}</td><td>MUR {r['amount']:,}</td><td>{esc(r['status'])}</td><td><form method="post" action="/admin/status"><input type="hidden" name="csrf" value="{token}"><input type="hidden" name="id" value="{esc(r['id'])}"><select name="status"><option value="pending_payment">Pending payment</option><option value="confirmed">Confirmed (manual verification)</option><option value="cancelled">Cancelled</option></select><button class="btn">Update</button></form></td></tr>''' for r in rows)
   priceforms=''.join(f'<form method="post" action="/admin/price"><h3>{esc(r["name"])}</h3><input type="hidden" name="csrf" value="{token}"><input type="hidden" name="villa" value="{esc(r["id"])}"><label>Nightly rate (MUR)<input type="number" name="nightly" min="0" max="1000000" value="{r["nightly"]}" required></label><button class="btn">Save price</button></form>' for r in villas)
   blockrows=''.join(f'<li>{esc(next((v['name'] for v in villas if v['id']==r['villa']),r['villa']))}: {esc(r["arrival"])} to {esc(r["departure"])} ({esc(r["reason"])})</li>' for r in blocked)
   propertyrows=''.join(f"<tr><td>{esc(v['name'])}</td><td>{esc(v['location'])}</td><td>{v['guests']}</td><td>MUR {v['nightly']:,}</td><td>{'Published' if v['published'] else 'Hidden'}</td><td><a href='/admin/property?id={esc(v['id'])}'>Edit</a></td></tr>" for v in villas)
   body=f'''<h1>Luxestays management</h1><p class="muted">Live database dashboard · {len(rows)} total reservations · Prices in MUR</p><p><a href="/book">Guest booking page</a> · <a href="/admin/logout">Sign out</a></p><h2>Upcoming reservations</h2><div class="scroll"><table><tr><th>Reference</th><th>Villa</th><th>Guest</th><th>Dates</th><th>Total</th><th>Status</th><th>Action</th></tr>{trs or '<tr><td colspan="7">No reservations yet.</td></tr>'}</table></div><h2>Availability — {month.strftime('%B %Y')}</h2><p>Orange: reservation held. Grey: owner block. Green: available. Airbnb bookings are not yet imported.</p><div class="columns">{cal}</div><h2>Manage properties</h2><p><a class="btn" href="/admin/property">+ Add a new villa</a></p><div class="scroll"><table><tr><th>Villa</th><th>Location</th><th>Guests</th><th>Nightly</th><th>Visibility</th><th>Edit</th></tr>{propertyrows}</table></div><h2>Nightly prices</h2><div class="columns">{priceforms}</div><h2>Block dates</h2><form method="post" action="/admin/block"><input type="hidden" name="csrf" value="{token}"><label>Villa<select name="villa">{''.join(f'<option value="{k}">{esc(v)}</option>' for k,v in ((r['id'],r['name']) for r in villas))}</select></label><label>Start<input type="date" name="arrival" required></label><label>End (checkout date)<input type="date" name="departure" required></label><label>Reason<input name="reason" maxlength="100" value="Owner block"></label><button class="btn">Block dates</button></form><ul>{blockrows}</ul><p class="note">Do not mark bookings confirmed until payment has been independently verified. Automatic payment confirmation and Airbnb sync are not connected.</p>'''
   self.send(200,layout('Management dashboard',body),headers=headers);return
  if path=='/':path='/index.html'
  name=path.lstrip('/')
  if '/' in name or name.startswith('.') or not name.endswith(('.html','.css','.js','.png','.jpg','.webp','.ico','.txt')):self.send(404,'Not found','text/plain');return
  f=ROOT/name
  if not f.is_file():self.send(404,'Not found','text/plain');return
  mime=mimetypes.guess_type(f.name)[0] or 'application/octet-stream'
  self.send(200,f.read_bytes(),mime+('; charset=utf-8' if mime.startswith('text/') else ''))
 def do_POST(self):
  path=urlparse(self.path).path
  try:f=self.read_form()
  except (ValueError,UnicodeError):self.send(400,'Invalid request');return
  if path=='/admin/login':
   if hmac.compare_digest(f.get('password','').encode(),PASSWORD.encode()):
    self.redirect('/admin',{'Set-Cookie':f'luxesession={cookie_value()}; HttpOnly; SameSite=Strict; Path=/'+('; Secure' if os.getenv('COOKIE_SECURE')=='1' else '')});return
   self.send(403,layout('Login failed','<h1>Incorrect password</h1><a href="/admin">Try again</a>'));return
  if path=='/book':
   try:
    v=f['villa'];a=f['arrival'];b=f['departure'];guest=f['guest'].strip();email=f['email'].strip();guests=int(f['guests'])
    if not 1<=guests<=50 or not 2<=len(guest)<=120 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or len(email)>200:raise ValueError('Check your guest details.')
    nights=valid_dates(a,b)
    with conn() as c:
     c.execute('BEGIN IMMEDIATE')
     villa=c.execute('SELECT * FROM villas WHERE id=? AND published=1',(v,)).fetchone()
     if not villa or guests>villa['guests']:raise ValueError('Villa not available or guest count exceeds capacity')
     rate=villa['nightly']
     if rate<=0:raise ValueError('This villa is not yet available for direct reservations. Please contact Luxestays.')
     if occupied(c,v,a,b):raise ValueError('Those dates are unavailable. Please choose different dates.')
     ref=secrets.token_hex(12)
     c.execute('INSERT INTO reservations VALUES(?,?,?,?,?,?,?,?,?,?)',(ref,v,guest,email,guests,a,b,rate*nights,'pending_payment',datetime.now(timezone.utc).isoformat()))
     c.commit()
    self.send(201,layout('Reservation received',f'<h1>Reservation request received</h1><p>Reference: <strong>{esc(ref)}</strong></p><p>{esc(villa['name'])} · {esc(a)} to {esc(b)} · {nights} nights · <strong>MUR {rate*nights:,}</strong></p><p class="note">Your reservation is pending payment and host verification. This is <strong>not</strong> a confirmed or paid booking. No payment has been taken. Please keep your reference.</p><a class="btn" href="/">Back to Luxestays</a>'));return
   except (ValueError,KeyError,OverflowError) as e:self.send(400,layout('Booking error',f'<h1>Unable to reserve</h1><p class="error">{esc(e)}</p><a href="/book">Try again</a>'));return
  if not self.admin_ok():self.send(403,'Sign in required');return
  if not self.check_csrf(f):self.send(403,'Invalid security token');return
  try:
   with conn() as c:
    if path=='/admin/property':
     vid=f.get('id','').strip();name=f.get('name','').strip();location=f.get('location','').strip();description=f.get('description','').strip();image=f.get('image','').strip()
     nightly=int(f['nightly']);guests=int(f['guests']);bedrooms=int(f['bedrooms']);published=1 if f.get('published')=='1' else 0
     if not 2<=len(name)<=100 or not 2<=len(location)<=150 or len(description)>3000 or not 0<=nightly<=1000000 or not 1<=guests<=50 or not 0<=bedrooms<=30 or len(image)>500 or (image and not image.startswith('https://')):raise ValueError('Check property fields')
     if vid:
      if not c.execute('SELECT 1 FROM villas WHERE id=?',(vid,)).fetchone():raise ValueError('Property not found')
      c.execute('UPDATE villas SET name=?,location=?,description=?,nightly=?,guests=?,bedrooms=?,image=?,published=? WHERE id=?',(name,location,description,nightly,guests,bedrooms,image,published,vid))
     else:
      vid='villa-'+secrets.token_hex(6)
      c.execute('INSERT INTO villas(id,name,nightly,location,description,guests,bedrooms,image,published) VALUES(?,?,?,?,?,?,?,?,?)',(vid,name,nightly,location,description,guests,bedrooms,image,published))
    elif path=='/admin/price':
     v=f['villa'];rate=int(f['nightly'])
     if not c.execute('SELECT 1 FROM villas WHERE id=?',(v,)).fetchone() or not 0<=rate<=1000000:raise ValueError('Invalid rate')
     c.execute('UPDATE villas SET nightly=? WHERE id=?',(rate,v))
    elif path=='/admin/block':
     v=f['villa'];a=f['arrival'];b=f['departure'];reason=f.get('reason','')[:100]
     if not c.execute('SELECT 1 FROM villas WHERE id=?',(v,)).fetchone():raise ValueError('Invalid villa')
     valid_dates(a,b)
     c.execute('BEGIN IMMEDIATE')
     if occupied(c,v,a,b):raise ValueError('Those dates already contain a booking or block')
     c.execute('INSERT INTO blocked(villa,arrival,departure,reason) VALUES(?,?,?,?)',(v,a,b,reason));c.commit()
    elif path=='/admin/status':
     status=f['status']
     if status not in ('pending_payment','confirmed','cancelled'):raise ValueError('Invalid status')
     c.execute('UPDATE reservations SET status=? WHERE id=?',(status,f['id']))
    else:self.send(404,'Not found');return
   self.redirect('/admin')
  except (ValueError,KeyError) as e:self.send(400,layout('Error',f'<h1>Could not save</h1><p>{esc(e)}</p><a href="/admin">Back to dashboard</a>'))

if __name__=='__main__':
 if len(PASSWORD)<12 or len(SECRET)<32:raise SystemExit('Set ADMIN_PASSWORD (12+ characters) and SESSION_SECRET (32+ characters) before starting. See README-BOOKING.md')
 setup()
 print(f'Luxestays booking server: http://{HOST}:{PORT} (payment gateway not connected)')
 ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
