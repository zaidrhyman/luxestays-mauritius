# Luxestays booking and management system

This upgrade keeps the existing Luxestays pages and adds `server.py`, a working Python-standard-library server with a SQLite reservation database, availability checks, password-protected dashboard, nightly-price editing, date blocks, and manual booking statuses.

## Run locally

Install Python 3.10 or later. In the `luxestays` folder, set two environment variables and start the server:

macOS / Linux:
```
export ADMIN_PASSWORD='your-own-long-unique-password'
export SESSION_SECRET='replace-with-a-random-secret-at-least-32-characters-long'
python3 server.py
```
Windows PowerShell:
```
$env:ADMIN_PASSWORD='your-own-long-unique-password'
$env:SESSION_SECRET='replace-with-a-random-secret-at-least-32-characters-long'
python server.py
```

Open http://127.0.0.1:8000 (website), http://127.0.0.1:8000/book (guest booking) and http://127.0.0.1:8000/admin (management). Set each villa's price in MUR first. Prices default to 0 to prevent bookings before rates are configured. Database is created as `luxestays.db` and contains guest personal data; back it up securely.

## What works

- Guests can submit a booking with dates and contact details; the server prevents overlapping active reservations and blocks and calculates the nightly total.
- Reservations are stored in SQLite with a unique reference and `pending_payment` status.
- Dashboard shows reservations and current-month calendar; update prices, block dates and manually change reservation statuses.
- JSON availability endpoint: `/api/availability?villa=pearl&arrival=2026-12-01&departure=2026-12-05`.

## What does NOT work yet

- **No online payment processing**. Guests are not charged; requests are NOT instant paid confirmations. Manual status updates must only follow independent payment verification.
- **No Airbnb synchronisation**. Airbnb dates are NOT reflected automatically. This creates double-booking risk. Import or block Airbnb dates before taking any live bookings.
- No transactional emails, automated unpaid-hold expiry, seasonal rates, taxes, fees, refunds or deposits. Car hire and activities remain enquiries.
- Calendar currently shows only current month; future reservations are in the bookings table.
- Existing property photos are illustrative and policies need owner/legal review.

## Going live

1. Confirm Mauritius business/payment provider eligibility, accommodation and tax requirements.
2. Choose a card provider that supports the registered business and its settlement bank; connect secure checkout and verify server-side webhooks before confirming any booking.
3. Implement reliable Airbnb calendar/channel sync and reconciliation, with safeguards against stale data.
4. Add email notifications, expiring unpaid holds, cancellation/refund handling and seasonal pricing.
5. Deploy on a Python-capable host with persistent database storage, HTTPS, backups and monitored uptime. Static hosting alone will not run this server. Set `COOKIE_SECURE=1` behind HTTPS, and use secure environment secrets.
6. Have the app security-reviewed and migrated to a maintained production framework before accepting real customer payments. This is a functional prototype, not an audited production booking platform.

Do not publish `.db` files or passwords to a public repository.

## Self-service property management (new)

- Open `/admin`, sign in, then select **+ Add a new villa**. Fill in the property name, location, description, capacity, bedroom count, nightly MUR price, and an HTTPS image URL. Click **Save property**. It will automatically appear on `/properties` and in the booking form if **Show on booking website** is checked.
- Choose **Edit** next to a villa to update its information or hide it from new bookings. Existing reservations are preserved.
- The main public collection is now `/properties` (linked from website navigation). The older static `/villas.html` file is retained for reference but is not the dynamic catalogue.
- Image uploads from your computer are **not** yet supported; use a hosted image URL. No automatic Airbnb sync or payment processing has been added.
- If an earlier `luxestays.db` already exists, the app adds new villa fields automatically without deleting existing reservations. Back up the database before upgrading.
- The initial two villas retain their existing detail pages. Newly added villas are presented in the dynamic catalogue; custom static detail pages are not generated.

**Deployment warning:** This remains a local development prototype, not an independently security-audited production system. Do not expose it to the public internet or collect real guest personal data until HTTPS, secure hosting, backups, anti-abuse protections, production-grade authentication, and Airbnb availability reconciliation have been implemented and tested. Unpaid requests currently hold dates indefinitely until manually cancelled. Card payments and automated confirmations are intentionally disabled.
